<template>
  <div class="about">
    <h1>This is an about page</h1>
    <h4>Click on logo area (App name) on top left of the page, to cycle between components</h4>
  </div>
</template>
